﻿using System;

namespace products.Model
{
    public class Product
    {
        public String ID { get; set; }
        public String Name { get; set; }
        public String Brand { get; set; }

    }
}
